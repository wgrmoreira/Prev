"""
Rotas para a aplicação PREV+
"""
from flask import Blueprint, request, jsonify, session
from datetime import datetime
from src.app import db
from src.models import Pedido, TipoPedido, StatusPedido

# Senha de administrador
ADMIN_PASSWORD = "480013"

def register_routes(app):
    """
    Registra as rotas da aplicação
    
    Args:
        app: Aplicação Flask
    """
    
    # Rotas de pedidos
    @app.route('/api/pedidos/atualizar', methods=['GET'])
    def atualizar_pedidos():
        """
        Atualiza os pedidos a partir do banco de dados
        
        Returns:
            Response: Resposta JSON com os pedidos atualizados
        """
        try:
            # Obter todos os pedidos não excluídos
            pedidos_abertos = Pedido.query.filter_by(status=StatusPedido.ABERTO).all()
            pedidos_concluidos = Pedido.query.filter_by(status=StatusPedido.CONCLUIDO).all()
            
            # Preparar dados para resposta
            pedidos_abertos_dict = [p.to_dict() for p in pedidos_abertos]
            pedidos_concluidos_dict = [p.to_dict() for p in pedidos_concluidos]
            
            # Contar pedidos por tipo
            contagem_sugestoes = Pedido.query.filter_by(tipo=TipoPedido.SUGESTAO, status=StatusPedido.ABERTO).count()
            contagem_manutencoes = Pedido.query.filter_by(tipo=TipoPedido.MANUTENCAO, status=StatusPedido.ABERTO).count()
            contagem_reclamacoes = Pedido.query.filter_by(tipo=TipoPedido.RECLAMACAO, status=StatusPedido.ABERTO).count()
            
            # Calcular percentual de concluídos
            total_pedidos = Pedido.query.filter(Pedido.status != StatusPedido.EXCLUIDO).count()
            total_concluidos = len(pedidos_concluidos)
            percentual_concluidos = int((total_concluidos / total_pedidos) * 100) if total_pedidos > 0 else 0
            
            return jsonify({
                'success': True,
                'pedidos_abertos': pedidos_abertos_dict,
                'pedidos_concluidos': pedidos_concluidos_dict,
                'contagem_por_tipo': {
                    'sugestoes': contagem_sugestoes,
                    'manutencoes': contagem_manutencoes,
                    'reclamacoes': contagem_reclamacoes
                },
                'percentual_concluidos': percentual_concluidos
            })
        except Exception as e:
            app.logger.error(f"Erro ao atualizar pedidos: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/pedidos/adicionar', methods=['POST'])
    def adicionar_pedido():
        """
        Adiciona um novo pedido
        
        Returns:
            Response: Resposta JSON com o resultado da operação
        """
        try:
            dados = request.json
            
            # Criar novo pedido
            novo_pedido = Pedido(
                nome=dados['nome'],
                bloco=dados['bloco'],
                apartamento=dados['apartamento'],
                tipo=dados['tipo'],
                descricao=dados['descricao'],
                status=StatusPedido.ABERTO
            )
            
            # Salvar no banco de dados
            db.session.add(novo_pedido)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Pedido adicionado com sucesso',
                'pedido': novo_pedido.to_dict()
            })
        except Exception as e:
            app.logger.error(f"Erro ao adicionar pedido: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/pedidos/concluir/<int:pedido_id>', methods=['POST'])
    def concluir_pedido(pedido_id):
        """
        Conclui um pedido
        
        Args:
            pedido_id: ID do pedido a ser concluído
            
        Returns:
            Response: Resposta JSON com o resultado da operação
        """
        try:
            # Verificar se o usuário é administrador
            if not session.get('admin', False):
                return jsonify({
                    'success': False,
                    'error': 'Acesso negado. Apenas administradores podem concluir pedidos.'
                }), 403
            
            dados = request.json
            
            # Buscar pedido
            pedido = Pedido.query.get(pedido_id)
            if not pedido:
                return jsonify({
                    'success': False,
                    'error': 'Pedido não encontrado'
                }), 404
            
            # Atualizar pedido
            pedido.status = StatusPedido.CONCLUIDO
            pedido.data_conclusao = datetime.now()
            pedido.conclusao = dados.get('conclusao', '')
            
            # Salvar no banco de dados
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Pedido concluído com sucesso',
                'pedido': pedido.to_dict()
            })
        except Exception as e:
            app.logger.error(f"Erro ao concluir pedido: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/pedidos/excluir/<int:pedido_id>', methods=['POST'])
    def excluir_pedido(pedido_id):
        """
        Exclui um pedido
        
        Args:
            pedido_id: ID do pedido a ser excluído
            
        Returns:
            Response: Resposta JSON com o resultado da operação
        """
        try:
            # Verificar se o usuário é administrador
            if not session.get('admin', False):
                return jsonify({
                    'success': False,
                    'error': 'Acesso negado. Apenas administradores podem excluir pedidos.'
                }), 403
            
            # Buscar pedido
            pedido = Pedido.query.get(pedido_id)
            if not pedido:
                return jsonify({
                    'success': False,
                    'error': 'Pedido não encontrado'
                }), 404
            
            # Marcar como excluído (soft delete)
            pedido.status = StatusPedido.EXCLUIDO
            
            # Salvar no banco de dados
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Pedido excluído com sucesso'
            })
        except Exception as e:
            app.logger.error(f"Erro ao excluir pedido: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    # Rotas de autenticação
    @app.route('/api/auth/login', methods=['POST'])
    def login():
        """
        Realiza o login do administrador
        
        Returns:
            Response: Resposta JSON com o resultado da operação
        """
        try:
            dados = request.json
            senha = dados.get('senha', '')
            
            if senha == ADMIN_PASSWORD:
                session['admin'] = True
                return jsonify({
                    'success': True,
                    'message': 'Login realizado com sucesso'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': 'Senha incorreta'
                }), 401
        except Exception as e:
            app.logger.error(f"Erro ao fazer login: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/auth/logout', methods=['POST'])
    def logout():
        """
        Realiza o logout do administrador
        
        Returns:
            Response: Resposta JSON com o resultado da operação
        """
        try:
            session.pop('admin', None)
            return jsonify({
                'success': True,
                'message': 'Logout realizado com sucesso'
            })
        except Exception as e:
            app.logger.error(f"Erro ao fazer logout: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/auth/status', methods=['GET'])
    def status():
        """
        Verifica o status de autenticação
        
        Returns:
            Response: Resposta JSON com o status de autenticação
        """
        try:
            is_admin = session.get('admin', False)
            return jsonify({
                'success': True,
                'admin': is_admin
            })
        except Exception as e:
            app.logger.error(f"Erro ao verificar status: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
