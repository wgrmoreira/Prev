"""
Arquivo principal da aplicação PREV+ para Render.com
"""
import os
from flask import Flask, render_template, jsonify, request, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import secrets

# Inicialização do app Flask
app = Flask(__name__, 
            static_folder='static',
            template_folder='templates')

# Configuração do banco de dados
# Em desenvolvimento, usamos SQLite
# Em produção (Render.com), usamos PostgreSQL
if 'DATABASE_URL' in os.environ:
    # Configuração para o Render.com (PostgreSQL)
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL').replace('postgres://', 'postgresql://')
else:
    # Configuração local (SQLite)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///prev_plus.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Chave secreta para sessões
app.config['SECRET_KEY'] = secrets.token_hex(16)

# Inicialização do SQLAlchemy
db = SQLAlchemy(app)

# Importação dos modelos e rotas
from models import Pedido, TipoPedido, StatusPedido
from routes import register_routes

# Registro das rotas
register_routes(app)

# Rota principal
@app.route('/')
def index():
    """
    Rota principal da aplicação
    
    Returns:
        Response: Página inicial
    """
    return render_template('index.html')

# Inicialização do banco de dados
@app.before_first_request
def create_tables():
    """
    Cria as tabelas no banco de dados antes da primeira requisição
    """
    db.create_all()

# Execução do app
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
