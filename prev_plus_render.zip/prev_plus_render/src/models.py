"""
Modelos de dados para a aplicação PREV+
"""
from datetime import datetime
from enum import Enum
from src.app import db

class TipoPedido(str, Enum):
    """Enum para tipos de pedidos"""
    SUGESTAO = "Sugestão"
    MANUTENCAO = "Manutenção"
    RECLAMACAO = "Reclamação"

class StatusPedido(str, Enum):
    """Enum para status de pedidos"""
    ABERTO = "Aberto"
    CONCLUIDO = "Concluido"
    EXCLUIDO = "Excluido"

class Pedido(db.Model):
    """Modelo para pedidos"""
    __tablename__ = 'pedidos'
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    bloco = db.Column(db.String(10), nullable=False)
    apartamento = db.Column(db.String(10), nullable=False)
    tipo = db.Column(db.String(20), nullable=False)
    descricao = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False, default=StatusPedido.ABERTO)
    data_criacao = db.Column(db.DateTime, nullable=False, default=datetime.now)
    data_conclusao = db.Column(db.DateTime, nullable=True)
    conclusao = db.Column(db.Text, nullable=True)
    
    def __init__(self, nome, bloco, apartamento, tipo, descricao, status=StatusPedido.ABERTO):
        self.nome = nome
        self.bloco = bloco
        self.apartamento = apartamento
        self.tipo = tipo
        self.descricao = descricao
        self.status = status
        self.data_criacao = datetime.now()
    
    def to_dict(self):
        """Converte o objeto para dicionário"""
        return {
            'id': self.id,
            'nome': self.nome,
            'bloco': self.bloco,
            'apartamento': self.apartamento,
            'tipo': self.tipo,
            'descricao': self.descricao,
            'status': self.status,
            'data_criacao': self.data_criacao.strftime('%d/%m/%Y %H:%M') if self.data_criacao else None,
            'data_conclusao': self.data_conclusao.strftime('%d/%m/%Y %H:%M') if self.data_conclusao else None,
            'conclusao': self.conclusao
        }
