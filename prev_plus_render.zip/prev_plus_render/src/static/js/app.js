// Script principal para a aplicação PREV+ (versão Flask com banco centralizado)

document.addEventListener('DOMContentLoaded', function() {
    // Elementos da interface
    const btnNovoPedidoDestaque = document.getElementById('btnNovoPedidoDestaque');
    const formNovoPedido = document.getElementById('formNovoPedido');
    const formLogin = document.getElementById('formLogin');
    const formConclusao = document.getElementById('formConclusao');
    const btnConfirmarExclusao = document.getElementById('btnConfirmarExclusao');
    const btnLogout = document.getElementById('btnLogout');
    const loginButton = document.getElementById('loginButton');
    const logoutButton = document.getElementById('logoutButton');
    
    // Contadores e containers
    const countSugestoes = document.getElementById('countSugestoes');
    const countManutencoes = document.getElementById('countManutencoes');
    const countReclamacoes = document.getElementById('countReclamacoes');
    const percentConcluidos = document.getElementById('percentConcluidos');
    const progressBar = document.getElementById('progressBar');
    const pedidosAbertosContainer = document.getElementById('pedidosAbertosContainer');
    const pedidosConcluidosContainer = document.getElementById('pedidosConcluidosContainer');
    
    // Campos de busca e filtros
    const searchAbertos = document.getElementById('searchAbertos');
    const searchConcluidos = document.getElementById('searchConcluidos');
    const filterTipo = document.getElementById('filterTipo');
    const filterBloco = document.getElementById('filterBloco');
    
    // Variáveis de estado
    let pedidosAbertos = [];
    let pedidosConcluidos = [];
    let pedidoParaExcluir = null;
    let isAdmin = false;
    
    // Modais
    const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
    const conclusaoModal = new bootstrap.Modal(document.getElementById('conclusaoModal'));
    const exclusaoModal = new bootstrap.Modal(document.getElementById('exclusaoModal'));
    
    // Inicialização
    verificarAutenticacao();
    atualizarPedidos();
    
    // Atualização automática a cada 30 segundos
    setInterval(atualizarPedidos, 30000);
    
    // Botão de novo pedido em destaque com rolagem automática
    btnNovoPedidoDestaque.addEventListener('click', function() {
        document.getElementById('novo-tab').click();
        // Adicionar pequeno atraso para garantir que a aba seja exibida antes da rolagem
        setTimeout(function() {
            // Rolar para a seção de formulário
            const formElement = document.getElementById('formNovoPedido');
            formElement.scrollIntoView({ behavior: 'smooth' });
        }, 300);
    });
    
    // Formulário de novo pedido
    formNovoPedido.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const novoPedido = {
            nome: document.getElementById('nome').value,
            bloco: document.getElementById('bloco').value,
            apartamento: document.getElementById('apartamento').value,
            tipo: document.getElementById('tipo').value,
            descricao: document.getElementById('descricao').value
        };
        
        adicionarPedido(novoPedido);
    });
    
    // Formulário de login
    formLogin.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const senha = document.getElementById('senha').value;
        
        login(senha);
    });
    
    // Botão de logout
    btnLogout.addEventListener('click', logout);
    
    // Formulário de conclusão
    formConclusao.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const pedidoId = document.getElementById('pedidoId').value;
        const conclusao = document.getElementById('conclusao').value;
        
        concluirPedido(pedidoId, conclusao);
    });
    
    // Botão de confirmação de exclusão
    btnConfirmarExclusao.addEventListener('click', function() {
        if (pedidoParaExcluir) {
            excluirPedido(pedidoParaExcluir);
        }
    });
    
    // Campos de busca
    searchAbertos.addEventListener('input', filtrarPedidosAbertos);
    searchConcluidos.addEventListener('input', filtrarPedidosConcluidos);
    
    // Filtros
    filterTipo.addEventListener('change', filtrarPedidosConcluidos);
    filterBloco.addEventListener('change', filtrarPedidosConcluidos);
    
    // Funções
    function verificarAutenticacao() {
        fetch('/api/auth/status')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    isAdmin = data.admin;
                    
                    if (isAdmin) {
                        loginButton.classList.add('d-none');
                        logoutButton.classList.remove('d-none');
                        
                        // Mostrar botões de administrador em todos os pedidos
                        document.querySelectorAll('.admin-actions').forEach(el => {
                            el.style.display = 'block';
                        });
                    } else {
                        loginButton.classList.remove('d-none');
                        logoutButton.classList.add('d-none');
                        
                        // Esconder botões de administrador
                        document.querySelectorAll('.admin-actions').forEach(el => {
                            el.style.display = 'none';
                        });
                    }
                }
            })
            .catch(error => {
                console.error('Erro ao verificar autenticação:', error);
            });
    }
    
    function atualizarPedidos() {
        fetch('/api/pedidos/atualizar')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Atualizar dados
                    pedidosAbertos = data.pedidos_abertos;
                    pedidosConcluidos = data.pedidos_concluidos;
                    
                    // Atualizar contadores
                    countSugestoes.textContent = data.contagem_por_tipo.sugestoes;
                    countManutencoes.textContent = data.contagem_por_tipo.manutencoes;
                    countReclamacoes.textContent = data.contagem_por_tipo.reclamacoes;
                    
                    // Atualizar progresso
                    percentConcluidos.textContent = data.percentual_concluidos + '%';
                    progressBar.style.width = data.percentual_concluidos + '%';
                    
                    // Renderizar pedidos
                    renderizarPedidosAbertos();
                    renderizarPedidosConcluidos();
                    
                    // Verificar autenticação
                    verificarAutenticacao();
                }
            })
            .catch(error => {
                console.error('Erro ao atualizar pedidos:', error);
                pedidosAbertosContainer.innerHTML = '<div class="alert alert-danger">Erro ao carregar pedidos. Tente novamente mais tarde.</div>';
                pedidosConcluidosContainer.innerHTML = '<div class="alert alert-danger">Erro ao carregar pedidos. Tente novamente mais tarde.</div>';
            });
    }
    
    function renderizarPedidosAbertos() {
        if (pedidosAbertos.length === 0) {
            pedidosAbertosContainer.innerHTML = '<div class="alert alert-info">Não há pedidos abertos no momento.</div>';
            return;
        }
        
        let html = '';
        
        pedidosAbertos.forEach(pedido => {
            html += criarCardPedido(pedido, true);
        });
        
        pedidosAbertosContainer.innerHTML = html;
        
        // Adicionar event listeners para botões de ação
        document.querySelectorAll('.btn-concluir').forEach(btn => {
            btn.addEventListener('click', function() {
                const pedidoId = this.getAttribute('data-id');
                document.getElementById('pedidoId').value = pedidoId;
                conclusaoModal.show();
            });
        });
        
        document.querySelectorAll('.btn-excluir').forEach(btn => {
            btn.addEventListener('click', function() {
                pedidoParaExcluir = this.getAttribute('data-id');
                exclusaoModal.show();
            });
        });
    }
    
    function renderizarPedidosConcluidos() {
        if (pedidosConcluidos.length === 0) {
            pedidosConcluidosContainer.innerHTML = '<div class="alert alert-info">Não há pedidos concluídos no momento.</div>';
            return;
        }
        
        let html = '';
        
        pedidosConcluidos.forEach(pedido => {
            html += criarCardPedido(pedido, false);
        });
        
        pedidosConcluidosContainer.innerHTML = html;
        
        // Adicionar event listeners para botões de exclusão em pedidos concluídos
        document.querySelectorAll('.btn-excluir-concluido').forEach(btn => {
            btn.addEventListener('click', function() {
                pedidoParaExcluir = this.getAttribute('data-id');
                exclusaoModal.show();
            });
        });
    }
    
    function criarCardPedido(pedido, aberto) {
        let tipoClass = '';
        
        switch (pedido.tipo) {
            case 'Sugestão':
                tipoClass = 'sugestao';
                break;
            case 'Manutenção':
                tipoClass = 'manutencao';
                break;
            case 'Reclamação':
                tipoClass = 'reclamacao';
                break;
        }
        
        let html = `
            <div class="card pedido-card ${tipoClass} mb-3">
                <div class="card-body">
                    <div class="pedido-header">
                        <span class="pedido-tipo ${tipoClass}">${pedido.tipo}</span>
                        <span class="pedido-data">${pedido.data_criacao}</span>
                    </div>
                    <div class="pedido-descricao">
                        <p>${pedido.descricao}</p>
                    </div>
                    <div class="pedido-footer">
                        <span class="pedido-solicitante">${pedido.nome}</span>
                        <span class="pedido-local">Bloco ${pedido.bloco}, Apto ${pedido.apartamento}</span>
                    </div>
        `;
        
        if (!aberto) {
            html += `
                    <hr>
                    <div class="conclusao-header">
                        <strong>Conclusão:</strong>
                        <span class="pedido-data">${pedido.data_conclusao}</span>
                    </div>
                    <div class="conclusao-descricao">
                        <p>${pedido.conclusao}</p>
                    </div>
                    <div class="mt-3 admin-actions" style="display: none;">
                        <button class="btn btn-danger btn-sm btn-excluir-concluido" data-id="${pedido.id}">
                            <i class="fas fa-trash me-1"></i> Excluir
                        </button>
                    </div>
            `;
        } else {
            html += `
                    <div class="mt-3 admin-actions" style="display: none;">
                        <button class="btn btn-success btn-sm btn-concluir" data-id="${pedido.id}">
                            <i class="fas fa-check me-1"></i> Concluir
                        </button>
                        <button class="btn btn-danger btn-sm btn-excluir" data-id="${pedido.id}">
                            <i class="fas fa-trash me-1"></i> Excluir
                        </button>
                    </div>
            `;
        }
        
        html += `
                </div>
            </div>
        `;
        
        return html;
    }
    
    function filtrarPedidosAbertos() {
        const termo = searchAbertos.value.toLowerCase();
        
        if (termo === '') {
            renderizarPedidosAbertos();
            return;
        }
        
        const pedidosFiltrados = pedidosAbertos.filter(pedido => 
            pedido.nome.toLowerCase().includes(termo) ||
            pedido.descricao.toLowerCase().includes(termo) ||
            pedido.tipo.toLowerCase().includes(termo) ||
            pedido.bloco.toString().includes(termo) ||
            pedido.apartamento.toString().includes(termo)
        );
        
        if (pedidosFiltrados.length === 0) {
            pedidosAbertosContainer.innerHTML = '<div class="alert alert-info">Nenhum pedido encontrado com os critérios de busca.</div>';
            return;
        }
        
        let html = '';
        
        pedidosFiltrados.forEach(pedido => {
            html += criarCardPedido(pedido, true);
        });
        
        pedidosAbertosContainer.innerHTML = html;
        
        // Adicionar event listeners para botões de ação
        document.querySelectorAll('.btn-concluir').forEach(btn => {
            btn.addEventListener('click', function() {
                const pedidoId = this.getAttribute('data-id');
                document.getElementById('pedidoId').value = pedidoId;
                conclusaoModal.show();
            });
        });
        
        document.querySelectorAll('.btn-excluir').forEach(btn => {
            btn.addEventListener('click', function() {
                pedidoParaExcluir = this.getAttribute('data-id');
                exclusaoModal.show();
            });
        });
    }
    
    function filtrarPedidosConcluidos() {
        const termo = searchConcluidos.value.toLowerCase();
        const tipo = filterTipo.value;
        const bloco = filterBloco.value;
        
        if (termo === '' && tipo === '' && bloco === '') {
            renderizarPedidosConcluidos();
            return;
        }
        
        const pedidosFiltrados = pedidosConcluidos.filter(pedido => {
            const matchTermo = termo === '' || 
                pedido.nome.toLowerCase().includes(termo) ||
                pedido.descricao.toLowerCase().includes(termo) ||
                pedido.tipo.toLowerCase().includes(termo) ||
                pedido.bloco.toString().includes(termo) ||
                pedido.apartamento.toString().includes(termo) ||
                (pedido.conclusao && pedido.conclusao.toLowerCase().includes(termo));
                
            const matchTipo = tipo === '' || pedido.tipo === tipo;
            const matchBloco = bloco === '' || pedido.bloco.toString() === bloco;
            
            return matchTermo && matchTipo && matchBloco;
        });
        
        if (pedidosFiltrados.length === 0) {
            pedidosConcluidosContainer.innerHTML = '<div class="alert alert-info">Nenhum pedido encontrado com os critérios de busca.</div>';
            return;
        }
        
        let html = '';
        
        pedidosFiltrados.forEach(pedido => {
            html += criarCardPedido(pedido, false);
        });
        
        pedidosConcluidosContainer.innerHTML = html;
        
        // Adicionar event listeners para botões de exclusão em pedidos concluídos
        document.querySelectorAll('.btn-excluir-concluido').forEach(btn => {
            btn.addEventListener('click', function() {
                pedidoParaExcluir = this.getAttribute('data-id');
                exclusaoModal.show();
            });
        });
    }
    
    function adicionarPedido(novoPedido) {
        fetch('/api/pedidos/adicionar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(novoPedido)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Limpar formulário
                formNovoPedido.reset();
                
                // Mostrar mensagem de sucesso
                alert('Pedido registrado com sucesso!');
                
                // Voltar para a aba de pedidos abertos
                document.getElementById('abertos-tab').click();
                
                // Atualizar pedidos
                atualizarPedidos();
            } else {
                alert('Erro ao registrar pedido: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Erro ao adicionar pedido:', error);
            alert('Erro ao registrar pedido. Tente novamente mais tarde.');
        });
    }
    
    function login(senha) {
        fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ senha: senha })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Fechar modal
                loginModal.hide();
                
                // Limpar formulário
                formLogin.reset();
                
                // Atualizar interface
                verificarAutenticacao();
                
                // Atualizar pedidos para mostrar botões de administrador
                atualizarPedidos();
            } else {
                alert('Senha incorreta!');
            }
        })
        .catch(error => {
            console.error('Erro ao fazer login:', error);
            alert('Erro ao fazer login. Tente novamente mais tarde.');
        });
    }
    
    function logout() {
        fetch('/api/auth/logout', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Atualizar interface
                verificarAutenticacao();
                
                // Atualizar pedidos para esconder botões de administrador
                atualizarPedidos();
            }
        })
        .catch(error => {
            console.error('Erro ao fazer logout:', error);
        });
    }
    
    function concluirPedido(pedidoId, conclusao) {
        fetch(`/api/pedidos/concluir/${pedidoId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ conclusao: conclusao })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Fechar modal
                conclusaoModal.hide();
                
                // Limpar formulário
                formConclusao.reset();
                
                // Atualizar pedidos
                atualizarPedidos();
                
                // Mostrar mensagem de sucesso
                alert('Pedido concluído com sucesso!');
            } else {
                alert('Erro ao concluir pedido: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Erro ao concluir pedido:', error);
            alert('Erro ao concluir pedido. Tente novamente mais tarde.');
        });
    }
    
    function excluirPedido(pedidoId) {
        fetch(`/api/pedidos/excluir/${pedidoId}`, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Fechar modal
                exclusaoModal.hide();
                
                // Resetar variável
                pedidoParaExcluir = null;
                
                // Atualizar pedidos
                atualizarPedidos();
                
                // Mostrar mensagem de sucesso
                alert('Pedido excluído com sucesso!');
            } else {
                alert('Erro ao excluir pedido: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Erro ao excluir pedido:', error);
            alert('Erro ao excluir pedido. Tente novamente mais tarde.');
        });
    }
});
